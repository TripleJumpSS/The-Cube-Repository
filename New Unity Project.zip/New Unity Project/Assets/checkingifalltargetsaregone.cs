﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class checkingifalltargetsaregone : MonoBehaviour
{
    public GameObject Target1;
    public GameObject Target2;
    public GameObject Target3;
    public GameObject GravityButton;

        void Start()
    {
        GravityButton.SetActive(false);
    }

    void Update()
    {

            if (Target1.activeInHierarchy == false && Target2.activeInHierarchy == false && Target3.activeInHierarchy == false)
             {GravityButton.SetActive(true);}
            
    }
}
