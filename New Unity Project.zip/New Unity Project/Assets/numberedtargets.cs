﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class numberedtargets : MonoBehaviour
{
    public GameObject ThisTarget;
    public GameObject ThePreviousTarget;
    public GameObject TheOtherTarget;
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Bullet")
        {
            if (ThePreviousTarget.activeInHierarchy == false)
             ThisTarget.SetActive(false);
             else
             {
                 ThisTarget.SetActive(true);
                 ThePreviousTarget.SetActive(true);
                 TheOtherTarget.SetActive(true);
             }
            }


}
}