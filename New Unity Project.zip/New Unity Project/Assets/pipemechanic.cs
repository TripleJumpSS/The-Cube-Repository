﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pipemechanic : MonoBehaviour
{
    
    public bool IsRotated; 

        void Start()
    {
        transform.rotation = Quaternion.Euler(0, 0, 0);
            IsRotated = false;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Bullet")
        {
            if (transform.rotation.x == 0)
            {transform.rotation = Quaternion.Euler(90, 0, 0);
            IsRotated = true;}
            else
            {transform.rotation = Quaternion.Euler(0, 0, 0);
            IsRotated = false;}
            }


}
}
