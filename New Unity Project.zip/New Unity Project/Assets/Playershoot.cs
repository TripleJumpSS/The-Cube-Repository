﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Playershoot : MonoBehaviour
{
    

    
    public Camera cam;
    public GameObject bullet;

    void Update()
    {
        if(Input.GetMouseButtonDown(0))
        {
            GameObject bulletObject = Instantiate(bullet);
            bulletObject.transform.position = cam.transform.position + cam.transform.forward;
            bulletObject.transform.forward = cam.transform.forward;
        }
    }
}
