﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class teleporttogravityfloor : MonoBehaviour
{
    public GameObject Player;
    public GameObject gravityfloor;

    void Update()
    {
        
    }

    void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Player")
        {
            print("whatever");
        }
    }
}
