﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class checkingifallpipesarestraight : MonoBehaviour
{
    public GameObject Pipe1;
    public GameObject Pipe2;
    public GameObject WaterField;
    public bool Pipe1IsRotate;
    public bool Pipe2IsRotate;

        void Start()
    {
        WaterField.SetActive(false);
    }

    void Update()
    {
        Pipe1IsRotate = Pipe1.GetComponent<pipemechanic>().IsRotated;
        Pipe2IsRotate = Pipe2.GetComponent<pipemechanic>().IsRotated;

            if (Pipe1IsRotate == true && Pipe2IsRotate == true)
             {WaterField.SetActive(true);}
             else
            {WaterField.SetActive(false);}
    }
}