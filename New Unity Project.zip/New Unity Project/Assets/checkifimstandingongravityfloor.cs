﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class checkifimstandingongravityfloor : MonoBehaviour
{
    public bool standingongravityfloor;
    public GameObject Cube;
    //public float CubeRotationNumber;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //CubeRotationNumber = Cube.transform.rotation;
    }

    void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Player")
        {
 
            {standingongravityfloor = true;
            print("whatever");
            }
        }
    }
    void OnTriggerExit(Collider other)
    {
        if(other.tag == "Player")
        {
            standingongravityfloor = false;
            print("whenever");
        }
    }
    
}
