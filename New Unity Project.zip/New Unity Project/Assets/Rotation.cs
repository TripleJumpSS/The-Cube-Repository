﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotation : MonoBehaviour
{
    //Rotational Speed
    public float speed = 0f;

    //Forward Direction
    public bool ForwardX = false;
    public bool ForwardY = false;
    public bool ForwardZ = false;

    //Reverse Direction
    public bool ReverseX = false;
    public bool ReverseY = false;
    public bool ReverseZ = false;

    public GameObject gravityfloor;
    public bool gravityfloorreader;
    public bool rotationcanstopnow;

    public float rotationnumber;
    public float xstop;
    public float ystop;
    public float zstop;

    void Update()
    {
        //Forward Direction
        if (ForwardX == true)
        {
            transform.Rotate(Time.deltaTime * speed, 0, 0, Space.Self);
        }
        if (ForwardY == true)
        {
            transform.Rotate(0, Time.deltaTime * speed, 0, Space.Self);
        }
        if (ForwardZ == true)
        {
            transform.Rotate(0, 0, Time.deltaTime * speed, Space.Self);
        }
        //Reverse Direction
        if (ReverseX == true)
        {
            transform.Rotate(-Time.deltaTime * speed, 0, 0, Space.Self);
        }
        if (ReverseY == true)
        {
            transform.Rotate(0, -Time.deltaTime * speed, 0, Space.Self);
        }
        if (ReverseZ == true)
        {
            transform.Rotate(0, 0, -Time.deltaTime * speed, Space.Self);
        }

        gravityfloorreader = gravityfloor.GetComponent<checkifimstandingongravityfloor>().standingongravityfloor;

        if(gravityfloorreader == true)
        {
            ForwardX = true;
        }
        if(gravityfloorreader == false)
        {
            ForwardX = false;
        }

        if (transform.rotation == Quaternion.Euler(xstop, ystop, zstop))
        {
            rotationcanstopnow = true;
            ForwardX = false;
        }
        else
        {
            rotationcanstopnow = false;
        }

    }


}